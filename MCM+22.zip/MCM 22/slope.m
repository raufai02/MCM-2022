%slope_function.m
%slope reflex agent
%assume aux and gmat are in the workspace already
%dV = bitcoin derivative, d2V = second derivative
dV = [0; diff(f_Val)];
d2V = [0; diff(dV)]; 

dVg = [0; diff(f_G)];

d2Vg = [0; diff(dVg)];

%
start = [1, 0, 0]; %starting weights

current = start;















